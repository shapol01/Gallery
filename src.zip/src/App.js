import Gallery from "./Gallery";

function App() {
  return (
    <>
      <Gallery/>
    </>
  );
}

export default App;
